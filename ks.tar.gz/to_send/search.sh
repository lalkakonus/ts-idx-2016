python2 query.py
