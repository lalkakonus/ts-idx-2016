python2 index.py $@
